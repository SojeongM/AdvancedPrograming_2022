from cv2 import FlannBasedMatcher

def prac3(p, input_txt_path, output_txt_path):

    with open(input_txt_path, "r") as f:
        input_lines = f.readlines()
    whole_points = input_lines
    x_list = [int(x.split(" ")[0]) for x in whole_points]
    y_list = [int(x.split(" ")[1]) for x in whole_points]

    q=[]
    for m in range(len(x_list)):
        q.append([x_list[m], y_list[m]])

    n=len(q)
    out_x=[]
    out_y=[]
    cnt=[0 for i in range(n)]

    
    for k in range(n):
        x=q[k][0]
        y=q[k][1]
        i=0
        j=len(p)-1
        odd_1=False
        
        for i in range(len(p)-1):
            if ((p[i][1]<=y) and (p[i+1][1]>y)) or ((p[i][1]>y) and (p[i+1][1]<=y)):
                if (x<((p[i+1][0]-p[i][0])*(y-p[i][1])/(p[i+1][1]-p[i][1]))+p[i][0]):
                    cnt[k]+=1
        '''    
         for i in range(len(p)):
            if((p[i][1]>y)!=p[j][1]>y) :
              if (x<((p[j][0]-p[i][0])*(y-p[i][1])/(p[j][1]-p[i][1]))+p[i][0]):
                    odd_1=not odd_1
                    
            j=i
            
        print(odd_1) '''
    
    ff=open(output_txt_path, "w")

    for j in range(len(cnt)):
        if(cnt[j]%2 == 0):
            data2='out\n'
        else:
            data2='in\n'
        ff.write(data2)
        
        
    
    ff.close()


def calc(a1, b1, c1):
    s=a1[0]*(b1[1]-c1[1])+b1[0]*(c1[1]-a1[1])+c1[0]*(a1[1]-b1[1])
    return s

    
def prac12(input_txt_path, output_txt_path):
    import matplotlib.pyplot as plt
    import numpy

    with open(input_txt_path, "r") as f:
        input_lines = f.readlines()
    whole_points = input_lines
    x_list = [int(x.split(" ")[0]) for x in whole_points]
    y_list = [int(x.split(" ")[1]) for x in whole_points]

    

    p=[]
    for m in range(len(x_list)):
        p.append([x_list[m], y_list[m]])

    n=len(x_list)
    p.sort()
    

    out_low=[]
    out_up=[]
    for i in p:
        while len(out_low) >= 2 and calc(out_low[-2], out_low[-1], i) <= 0:
            out_low.pop()
        out_low.append(i)

    q=reversed(p)
    for i in q:
        while len(out_up) >= 2 and calc(out_up[-2], out_up[-1], i) <= 0:
            out_up.pop()
        out_up.append(i)
    '''
    출력 정리
    '''
    output = out_low[:-1]+out_up[:-1]
    area = 0
    for i in range(len(output)-1):
        area+=(output[i][0]*output[i+1][1])-(output[i+1][0]*output[i][1])
    area+=(output[len(output)-1][0]*output[0][1])-(output[0][0]*output[len(output)-1][1])
    area=round(abs(area)/2, 1)
    
    

    ff=open(output_txt_path, "w")
    data='{0}\n'.format(area)
    ff.write(data)
    for i in range(len(output)):
        data2='{a} {b}\n'.format(a=output[i][0],b= output[i][1])
        ff.write(data2)
    
    ff.close()
    return output

def display(input_txt_path, output_txt_path):
    import matplotlib.pyplot as plt
    import numpy
    '''
    input1 : input_txt_path = path of input_example.txt
    input2 : output_txt_path = path of output_example.txt
    return : save convex_hull image
    '''
    
    with open(input_txt_path, "r") as f:
        input_lines = f.readlines()
    with open(output_txt_path, "r") as f:
        output_lines = f.readlines()
        
    whole_points = input_lines
    area = round(float(output_lines[0]), 1)
    hull_points = output_lines[1:]

    x_list = [int(x.split(" ")[0]) for x in whole_points]
    y_list = [int(x.split(" ")[1]) for x in whole_points]
    plt.plot(x_list, y_list, marker='.', linestyle='None')     
   
   
    hx_list = [int(x.split(" ")[0]) for x in hull_points]
    hy_list = [int(x.split(" ")[1]) for x in hull_points]

    plt.plot(hx_list, hy_list, marker='*', linestyle='None', markersize=10)

    title = plt.title(f'Area : {area}')
    plt.setp(title, color='r')
    plt.savefig(output_txt_path[:-3]+"png", bbox_inches='tight')


if __name__ == "__main__":
    
    input_txt_path = "./input1.txt"
    output_txt_path = "./문소정_output1.txt"
    q=prac12(input_txt_path, output_txt_path)
    in_out = "./point_in_polygon_input.txt"
    out_out = "./문소정_point_in_polygon_output1.txt"
    prac3(q, in_out, out_out)
    display(input_txt_path, output_txt_path)

    input_txt_path = "./input2.txt"
    output_txt_path = "./문소정_output2.txt"
    m=prac12(input_txt_path, output_txt_path)
    in_out = "./point_in_polygon_input.txt"
    out_out = "./문소정_point_in_polygon_output2.txt"
    prac3(m, in_out, out_out)
    display(input_txt_path, output_txt_path)

    input_txt_path = "./input3.txt"
    output_txt_path = "./문소정_output3.txt"
    n=prac12(input_txt_path, output_txt_path)
    in_out = "./point_in_polygon_input.txt"
    out_out = "./문소정_point_in_polygon_output3.txt"
    prac3(n, in_out, out_out)
    display(input_txt_path, output_txt_path)

